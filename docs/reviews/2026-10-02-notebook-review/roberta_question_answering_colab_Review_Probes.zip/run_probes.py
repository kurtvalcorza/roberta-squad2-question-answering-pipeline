"""Row 76 probes: roberta_question_answering_colab.ipynb (review only, CPU only).

Executes the notebook's own carried module cells (2/3/4 of Section 2) in a module namespace, then runs
static, data, BYOD and model probes. CPU only (CUDA_VISIBLE_DEVICES=-1). Model weights and the corpus zip
are read from the pre-staged copies in the main checkout (read-only); nothing is downloaded.

Usage: python run_probes.py <worktree> <outdir>
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import re
import sys
import time
import types
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
WT = Path(sys.argv[1])
OUT = Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
MAIN = Path(r"C:\Users\Kurt Valcorza\Projects\roberta-squad2-question-answering-pipeline")
NB_PATH = WT / "tutorials" / "roberta_question_answering_colab.ipynb"
results: dict = {}


def save():
    (OUT / "results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]

# ---------- S: static ----------
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
results["static"] = {
    "n_cells": len(cells),
    "code_cells": code_idx,
    "declared_spec": nb["metadata"]["dimer"]["notebook_spec"],
    "generated_from_revision": nb["metadata"]["dimer"]["generated_from"]["revision"],
    "pip_install_into_kernel": "'-m', 'pip', 'install'" in src[3],
    "restart_guard_raises": "Restart the runtime, then rerun from the top" in src[3],
    "uses_uv": any("uv " in s or "uv venv" in s for s in src),
    "google_colab_import_cells": [i for i, s in enumerate(src) if "google.colab" in s],
    "byod_path_field": bool(re.search(r"^\w*PATH\w* = .*# @param", src[13], re.M)),
    "form_fields": [l.strip() for s in src for l in s.splitlines() if "# @param" in l],
    "asserts_outside_modules": {i: [l.strip() for l in src[i].splitlines() if l.strip().startswith("assert")] for i in code_idx if i not in (5, 7, 9)},
    "guided_markers": {k: any(k.lower() in s.lower() for s in src) for k in ("How to use this notebook", "Roadmap", "Glossary", "Predict", "Checkpoint", "Troubleshooting", "Infrastructure", "Sample answer", "<details", "Expected result", "What to notice", "Look for")},
    "prose_null_baseline_zero": "zero here" in src[16],
    "ci_env_var_documented_in_markdown": any("DIMER_NOTEBOOK_CI_PREINSTALLED" in src[i] for i, c in enumerate(cells) if c["cell_type"] == "markdown"),
    "rerun_instruction_in_optional_experiments": "re-run" in src[24].split("Optional experiments")[1].lower() or "rerun" in src[24].split("Optional experiments")[1].lower(),
}
save()

# ---------- load carried modules from the notebook ----------
mod = types.ModuleType("nbcarried")
sys.modules["nbcarried"] = mod
for i in (5, 7, 9):
    exec(compile(src[i], f"<nb cell {i}>", "exec"), mod.__dict__)
M = mod

# ---------- D: data ----------
t0 = time.perf_counter()
corpus = M.read_corpus(M.fetch_corpus(cache_dir=MAIN / "weights" / "adversarialqa"))
splits = M.build_sample_dataset(corpus, seed=42)
manif = {n: M.validate_dataset(p) for n, p in splits.items()}
disjoint = M.check_split_disjoint(splits)
titles = {n: {r["title"].lower() for r in p} for n, p in splits.items()}
train_pool_titles = {r["title"].lower() for r in corpus["train"]}
dev_titles = {r["title"].lower() for r in corpus["dev"]}

def words(s):
    return set(M.normalize_answer(s).split())

def shingles(s, k=5):
    w = M.normalize_answer(s).split()
    return {tuple(w[i:i + k]) for i in range(max(1, len(w) - k + 1))}

def jacc(a, b):
    return len(a & b) / max(1, len(a | b))

train_ctx = {r["context"] for r in splits["train"]}
train_sh = [(c, shingles(c)) for c in train_ctx]
near_ctx = []
for name in ("validation", "test"):
    for c in {r["context"] for r in splits[name]}:
        sc = shingles(c)
        best = max(jacc(sc, s) for _c, s in train_sh)
        if best >= 0.3:
            near_ctx.append({"split": name, "jaccard5": round(best, 3), "ctx": c[:80]})
train_q = [words(r["question"]) for r in splits["train"]]
near_q = 0
for r in splits["test"]:
    wq = words(r["question"])
    if max(jacc(wq, t) for t in train_q) >= 0.8:
        near_q += 1
# questions per passage (SQuAD shares passages across questions)
from collections import Counter
qpp = {n: round(len(p) / len({r["context"] for r in p}), 2) for n, p in splits.items()}
# Section 9 'new' records (cell 23, sample branch) and their articles
used = {r["context"].lower() for part in splits.values() for r in part}
cands = [r for r in corpus["dev"] if r["context"].lower() not in used and r["answers"] and len(r["context"]) <= M.MAX_CONTEXT_CHARS]
new_titles = sorted({r["title"].lower() for r in cands[:12]})
results["data"] = {
    "raw": {k: len(v) for k, v in corpus.items()},
    "splits": disjoint,
    "articles": {n: len(t) for n, t in titles.items()},
    "digests": {n: m["digest"][:8] for n, m in manif.items()},
    "unanswerable": {n: m["unanswerable"] for n, m in manif.items()},
    "train_pool_vs_dev_title_overlap": sorted(train_pool_titles & dev_titles),
    "questions_per_passage": qpp,
    "near_dup_passages_train_vs_valtest_j5_ge_0.3": near_ctx[:10],
    "n_near_dup_passages": len(near_ctx),
    "test_questions_near_dup_of_train_question_j_ge_0.8": near_q,
    "dev_titles": len(dev_titles),
    "valtest_titles": len(titles["validation"] | titles["test"]),
    "section9_new_record_titles": new_titles,
    "section9_new_titles_in_val_or_test": sorted(set(new_titles) & (titles["validation"] | titles["test"])),
    "null_baseline_test": M.null_baseline(splits["test"]),
    "seconds": round(time.perf_counter() - t0, 1),
}
save()

# ---------- B: BYOD ----------
byod = {}
work = OUT / "byod"
work.mkdir(exist_ok=True)

def cell13_probes(sp):
    """The probe block of notebook cell 13, verbatim logic."""
    out = []
    probes = {
        'duplicate id': [{**r, 'id': 'same'} for r in sp['train'][:8]],
        'gold span at the wrong offset': [{**sp['train'][0], 'answers': [{'text': sp['train'][0]['answers'][0]['text'], 'answer_start': 0}]}, *sp['train'][1:8]],
        'missing field': [{'id': r['id'], 'question': r['question'], 'context': r['context']} for r in sp['train'][:8]],
        'too small': sp['train'][:3],
    }
    for name, probe in probes.items():
        try:
            M.validate_dataset(probe)
            out.append({'probe': name, 'verdict': 'accepted'})
        except (TypeError, ValueError) as exc:
            out.append({'probe': name, 'rejected': str(exc)[:80]})
    return out

def run_cell13_byod(records, seed=42):
    sp = M.split_dataset(records, seed=seed)
    {n: M.validate_dataset(p) for n, p in sp.items()}
    M.check_split_disjoint(sp)
    return sp, cell13_probes(sp)

# B1: SQuAD-2-style BYOD with unanswerable records (1 question per passage), 60 records
pool = [r for r in corpus["train"] if len(r["context"]) <= 1300]
rng = random.Random(1)
byctx = {}
for r in pool:
    byctx.setdefault(r["context"], r)
uniq = list(byctx.values())
rng.shuffle(uniq)
def mk(n, unans_every=3):
    recs = []
    for i, r in enumerate(uniq[:n]):
        a = [] if i % unans_every == 0 else r["answers"]
        recs.append({"id": f"b{i:03d}", "question": r["question"], "context": r["context"], "answers": a})
    return recs
csvp = work / "byod60.csv"
with open(csvp, "w", encoding="utf-8", newline="") as h:
    w = csv.DictWriter(h, fieldnames=["id", "question", "context", "answer_text", "answer_start"])
    w.writeheader()
    for r in mk(60):
        w.writerow({"id": r["id"], "question": r["question"], "context": r["context"], "answer_text": r["answers"][0]["text"] if r["answers"] else "", "answer_start": r["answers"][0]["answer_start"] if r["answers"] else ""})
loaded = M.load_byod_dataset(csvp)
crashes = []
for seed in range(10):
    try:
        sp, pr = run_cell13_byod(loaded, seed=seed)
        crashes.append({"seed": seed, "first_train_unanswerable": not sp["train"][0]["answers"], "ok": True})
    except Exception as exc:  # noqa: BLE001
        crashes.append({"seed": seed, "error": f"{type(exc).__name__}: {str(exc)[:90]}"})
byod["csv60_one_third_unanswerable_cell13_by_seed"] = crashes
# B2: smallest BYOD size that passes cell 13 (one question per passage, all answerable)
sizes = {}
for n in (8, 12, 20, 30, 38, 40, 45, 50, 53, 54, 60):
    try:
        run_cell13_byod(mk(n, unans_every=10**9))
        sizes[n] = "ok"
    except Exception as exc:  # noqa: BLE001
        sizes[n] = f"{type(exc).__name__}: {str(exc)[:70]}"
byod["min_size_one_q_per_passage"] = sizes
# B3: invalid inputs -> messages
inv = {}
bad = work / "bad.csv"
bad.write_text("id,question,context\nx,q,c\n", encoding="utf-8")
for label, path in (("csv missing columns", bad), ("txt file", work / "x.txt")):
    if label == "txt file":
        path.write_text("hello", encoding="utf-8")
    try:
        M.load_byod_dataset(path)
        inv[label] = "accepted"
    except Exception as exc:  # noqa: BLE001
        inv[label] = f"{type(exc).__name__}: {str(exc)[:100]}"
byod["invalid_inputs"] = inv
# B4: wrong-offset probe accepted when gold already starts at 0?
r0 = next(r for r in uniq if r["answers"] and r["answers"][0]["answer_start"] == 0) if any(r["answers"] and r["answers"][0]["answer_start"] == 0 for r in uniq) else None
byod["wrong_offset_probe_with_gold_at_0"] = None if r0 is None else cell13_probes({"train": [dict(r0, id="z0")] + [dict(r, id=f"z{i}") for i, r in enumerate(uniq[1:8], 1)]})[1]
results["byod"] = byod
save()

# ---------- R: model probes (CPU) ----------
import numpy as np
import torch
torch.set_num_threads(max(1, (os.cpu_count() or 4) // 2))
WEIGHTS = MAIN / "weights" / "roberta-base-squad2"
t0 = time.perf_counter()
pipe = M.RoBERTaQuestionAnsweringPipeline.from_pretrained(weights_dir=WEIGHTS, device="cpu")
model_res = {"device": pipe.device, "torch": torch.__version__, "load_s": round(time.perf_counter() - t0, 1)}
fit = {n: pipe.check_fit(p) for n, p in splits.items()}
model_res["fit_dropped"] = {n: f["dropped"] for n, f in fit.items()}
train_r, val_r, test_r = fit["train"]["fitting"], fit["validation"]["fitting"], fit["test"]["fitting"]

def forced_span(question, context, k=15):
    s, e, off, cm = pipe._runner(question, context)
    s = np.where(cm, s, -1e4); e = np.where(cm, e, -1e4)
    ps = np.exp(s - s.max()); ps /= ps.sum(); pe = np.exp(e - e.max()); pe /= pe.sum()
    outer = np.tril(np.triu(np.outer(ps, pe)), k - 1)
    outer[~cm, :] = 0; outer[:, ~cm] = 0
    a, b = np.unravel_index(int(np.argmax(outer)), outer.shape)
    return context[int(off[a][0]):int(off[b][1])]

t0 = time.perf_counter()
frozen = pipe.evaluate(test_r)
forced = M.qa_metrics([forced_span(r["question"], r["context"]) for r in test_r], [M.gold_texts(r) for r in test_r])
model_res["frozen_test"] = {k: round(frozen[k], 2) for k in ("exact_match", "f1", "answered_rate")}
model_res["frozen_forced_span_test_no_null"] = {k: round(forced[k], 2) for k in ("exact_match", "f1", "answered_rate")}
model_res["frozen_eval_s"] = round(time.perf_counter() - t0, 1)
results["model"] = model_res
save()

# R2: rerun-state probe (stand-in sizes: 48 train, 24 val, lr 1e-4, 1 epoch)
tiny_train, tiny_val, probe_set = train_r[:48], val_r[:24], test_r[:40]
frozen_val = pipe.evaluate(tiny_val)
first = pipe.adapt(tiny_train, tiny_val, epochs=1, lr=1e-4, batch_size=16, trainable_encoder_layers=2)
after_first_test = pipe.evaluate(probe_set)
# learner reruns Section 6 ('frozen' score) after adaptation
rerun_sec6_frozen = pipe.evaluate(probe_set)
second = pipe.adapt(tiny_train, tiny_val, epochs=1, lr=1e-4, batch_size=16, trainable_encoder_layers=1)
art = OUT / "artifact_rerun"
import shutil
shutil.rmtree(art, ignore_errors=True)
pipe.save_artifact(art)
reloaded = M.RoBERTaQuestionAnsweringPipeline.from_artifact(art, weights_dir=WEIGHTS, device="cpu")
before = [pipe.answer(r["question"], r["context"])["answer"] for r in probe_set]
after = [reloaded.answer(r["question"], r["context"])["answer"] for r in probe_set]
sd1, sd2 = pipe._model.state_dict(), reloaded._model.state_dict()
diff_keys = sorted({k.split(".")[3] if k.startswith("roberta.encoder.layer.") else k.split(".")[0] for k in sd1 if not torch.equal(sd1[k], sd2[k])})
s1, e1, _, _ = pipe._runner(probe_set[0]["question"], probe_set[0]["context"])
s2, e2, _, _ = reloaded._runner(probe_set[0]["question"], probe_set[0]["context"])
results["rerun"] = {
    "stand_in": "48 train / 24 val / 40 test-probe records, lr 1e-4, 1 epoch per adapt (not the default config)",
    "true_frozen_val_f1": round(frozen_val["f1"], 2),
    "first_adapt_epoch0_val_f1": round(first["history"][0]["val"]["f1"], 2),
    "second_adapt_epoch0_val_f1_labelled_frozen_model": round(second["history"][0]["val"]["f1"], 2),
    "second_adapt_epoch0_note": second["history"][0].get("note"),
    "section6_rerun_after_adapt_f1_on_probe_set": round(rerun_sec6_frozen["f1"], 2),
    "section6_rerun_evaluate_adapted_flag": rerun_sec6_frozen["adapted"],
    "true_frozen_f1_on_probe_set": round(pipe and M.qa_metrics([], [])["f1"] if False else 0, 2),
    "artifact_tensors": len(json.loads((art / "manifest.json").read_text())["tensors"]),
    "reload_parity_identical_answers": sum(a == b for a, b in zip(before, after)),
    "reload_parity_of": len(before),
    "state_dict_groups_differing_after_reload": diff_keys,
    "max_abs_start_logit_diff_record0": float(np.max(np.abs(np.asarray(s1) - np.asarray(s2)))),
}
save()
# true frozen on the probe set for comparison (fresh base)
base = M.RoBERTaQuestionAnsweringPipeline.from_pretrained(weights_dir=WEIGHTS, device="cpu")
results["rerun"]["true_frozen_f1_on_probe_set"] = round(base.evaluate(probe_set)["f1"], 2)
results["rerun"]["after_first_adapt_f1_on_probe_set"] = round(after_first_test["f1"], 2)
save()
print(json.dumps(results, indent=1, default=str)[:6000])
